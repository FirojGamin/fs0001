import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Route } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

export default function RecentActivity() {
  const { data: invoices, isLoading: invoicesLoading } = useQuery({
    queryKey: ["/api/invoices"],
  });

  const { data: trips, isLoading: tripsLoading } = useQuery({
    queryKey: ["/api/trips"],
  });

  const { data: clients } = useQuery({
    queryKey: ["/api/clients"],
  });

  const recentInvoices = invoices?.slice(-3) || [];
  const recentTrips = trips?.slice(-3) || [];

  const getClientName = (clientId: number) => {
    const client = clients?.find((c: any) => c.id === clientId);
    return client?.companyName || "Unknown Client";
  };

  if (invoicesLoading || tripsLoading) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {[...Array(2)].map((_, i) => (
          <Card key={i}>
            <CardHeader>
              <Skeleton className="h-6 w-32" />
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[...Array(3)].map((_, j) => (
                  <div key={j} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <Skeleton className="w-10 h-10 rounded-lg" />
                      <div className="ml-3 space-y-2">
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-3 w-16" />
                      </div>
                    </div>
                    <div className="text-right space-y-2">
                      <Skeleton className="h-4 w-16" />
                      <Skeleton className="h-3 w-20" />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Recent Invoices */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold text-gray-900">Recent Invoices</CardTitle>
            <Button variant="link" className="text-primary hover:text-primary/80 p-0">
              View All
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {recentInvoices.length === 0 ? (
            <div className="text-center py-8">
              <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No invoices created yet</p>
            </div>
          ) : (
            <div className="space-y-4">
              {recentInvoices.map((invoice: any) => (
                <div key={invoice.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <FileText className="w-5 h-5 text-blue-500" />
                    </div>
                    <div className="ml-3">
                      <p className="font-medium text-gray-900">{getClientName(invoice.clientId)}</p>
                      <p className="text-sm text-gray-500">{invoice.invoiceNumber}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-gray-900">₹{parseFloat(invoice.totalAmount).toLocaleString('en-IN')}</p>
                    <p className="text-sm text-gray-500">{format(new Date(invoice.invoiceDate), 'MMM dd, yyyy')}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recent Trips */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold text-gray-900">Recent Trips</CardTitle>
            <Button variant="link" className="text-primary hover:text-primary/80 p-0">
              View All
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {recentTrips.length === 0 ? (
            <div className="text-center py-8">
              <Route className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No trips recorded yet</p>
            </div>
          ) : (
            <div className="space-y-4">
              {recentTrips.map((trip: any) => (
                <div key={trip.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                      <Route className="w-5 h-5 text-green-500" />
                    </div>
                    <div className="ml-3">
                      <p className="font-medium text-gray-900">{trip.startLocation} → {trip.endLocation}</p>
                      <p className="text-sm text-gray-500">{trip.clientId ? getClientName(trip.clientId) : 'No client'}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-gray-900">{parseFloat(trip.distance).toFixed(0)} km</p>
                    <p className="text-sm text-gray-500">{format(new Date(trip.tripDate), 'MMM dd, yyyy')}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
