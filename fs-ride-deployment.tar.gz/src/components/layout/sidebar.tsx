import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Car, LayoutDashboard, FileText, Users, Receipt, MapPin, Download, Settings } from "lucide-react";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (page: string) => void;
}

export default function Sidebar({ isOpen, onClose, onNavigate }: SidebarProps) {
  const [location] = useLocation();

  const navigationItems = [
    { name: "Dashboard", icon: LayoutDashboard, active: location === "/", onClick: () => onClose() },
    { name: "Create Invoice", icon: FileText, onClick: () => { onNavigate('invoice'); onClose(); } },
    { name: "Clients", icon: Users, onClick: () => { onNavigate('clients'); onClose(); } },
    { name: "Expenses", icon: Receipt, onClick: () => { onNavigate('expenses'); onClose(); } },
  ];

  const toolItems = [
    { name: "GPS Distance", icon: MapPin, onClick: () => { onNavigate('gps'); onClose(); } },
    { name: "Reports", icon: Download, onClick: () => {} },
    { name: "Settings", icon: Settings, onClick: () => {} },
  ];

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div 
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform transition-transform duration-200 ease-in-out",
          isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        {/* Logo */}
        <div className="flex items-center justify-center h-16 bg-primary text-white">
          <Car className="w-8 h-8 mr-3" />
          <span className="text-xl font-bold">FS RIDE</span>
        </div>

        {/* Navigation */}
        <nav className="mt-8">
          <div className="px-6 py-3">
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Main</h3>
          </div>
          
          {navigationItems.map((item) => (
            <button
              key={item.name}
              onClick={item.onClick}
              className={cn(
                "group flex items-center w-full px-6 py-3 text-sm font-medium text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors",
                item.active && "border-r-3 border-blue-500 bg-blue-50 text-blue-600"
              )}
            >
              <item.icon className="w-5 h-5 mr-3" />
              {item.name}
            </button>
          ))}

          <div className="px-6 py-3 mt-8">
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Tools</h3>
          </div>

          {toolItems.map((item) => (
            <button
              key={item.name}
              onClick={item.onClick}
              className="group flex items-center w-full px-6 py-3 text-sm font-medium text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
            >
              <item.icon className="w-5 h-5 mr-3" />
              {item.name}
            </button>
          ))}
        </nav>
      </div>
    </>
  );
}
