import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Upload, Fuel, Car, ParkingCircle, Utensils, MoreHorizontal, Eye, Trash2, Receipt } from "lucide-react";
import { insertExpenseSchema, type Expense } from "@shared/schema";
import { z } from "zod";
import { format } from "date-fns";

const expenseFormSchema = insertExpenseSchema.extend({
  clientId: z.string().optional(),
  date: z.string().min(1, "Date is required"),
});

type ExpenseFormData = z.infer<typeof expenseFormSchema>;

interface ExpenseModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ExpenseModal({ isOpen, onClose }: ExpenseModalProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [filterType, setFilterType] = useState<string>("all");
  const [filterDate, setFilterDate] = useState<string>("");
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: expenses, isLoading } = useQuery({
    queryKey: ["/api/expenses"],
  });

  const { data: clients } = useQuery({
    queryKey: ["/api/clients"],
  });

  const { register, handleSubmit, formState: { errors }, reset, setValue } = useForm<ExpenseFormData>({
    resolver: zodResolver(expenseFormSchema),
    defaultValues: {
      date: new Date().toISOString().split('T')[0],
      type: "fuel",
    },
  });

  const createExpenseMutation = useMutation({
    mutationFn: (formData: FormData) => 
      fetch("/api/expenses", {
        method: "POST",
        body: formData,
      }).then(res => {
        if (!res.ok) throw new Error("Failed to create expense");
        return res.json();
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/expenses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Expense added successfully",
      });
      reset();
      setSelectedFile(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add expense",
        variant: "destructive",
      });
    },
  });

  const deleteExpenseMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/expenses/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/expenses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Expense deleted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete expense",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ExpenseFormData) => {
    const formData = new FormData();
    formData.append('type', data.type);
    formData.append('amount', data.amount.toString());
    formData.append('date', data.date);
    formData.append('description', data.description || '');
    if (data.clientId) {
      formData.append('clientId', data.clientId);
    }
    if (selectedFile) {
      formData.append('receipt', selectedFile);
    }

    createExpenseMutation.mutate(formData);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "Error",
          description: "File size must be less than 5MB",
          variant: "destructive",
        });
        return;
      }
      setSelectedFile(file);
    }
  };

  const handleDelete = (expense: Expense) => {
    if (confirm("Are you sure you want to delete this expense?")) {
      deleteExpenseMutation.mutate(expense.id);
    }
  };

  const getExpenseIcon = (type: string) => {
    switch (type) {
      case 'fuel':
        return <Fuel className="w-5 h-5 text-yellow-500" />;
      case 'toll':
        return <Car className="w-5 h-5 text-blue-500" />;
      case 'parking':
        return <ParkingCircle className="w-5 h-5 text-green-500" />;
      case 'food':
        return <Utensils className="w-5 h-5 text-orange-500" />;
      default:
        return <MoreHorizontal className="w-5 h-5 text-gray-500" />;
    }
  };

  const getExpenseIconBg = (type: string) => {
    switch (type) {
      case 'fuel':
        return 'bg-yellow-100';
      case 'toll':
        return 'bg-blue-100';
      case 'parking':
        return 'bg-green-100';
      case 'food':
        return 'bg-orange-100';
      default:
        return 'bg-gray-100';
    }
  };

  const filteredExpenses = expenses?.filter((expense: Expense) => {
    const typeMatch = filterType === "all" || expense.type === filterType;
    const dateMatch = !filterDate || expense.date.toString().startsWith(filterDate);
    return typeMatch && dateMatch;
  }) || [];

  const getClientName = (clientId: number | null) => {
    if (!clientId) return "No client";
    const client = clients?.find((c: any) => c.id === clientId);
    return client?.companyName || "Unknown Client";
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Expense Tracker</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Add Expense Form */}
          <div className="lg:col-span-1">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Add New Expense</h3>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div>
                <Label htmlFor="type">Expense Type *</Label>
                <Select onValueChange={(value) => setValue('type', value as any)} defaultValue="fuel">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fuel">Fuel</SelectItem>
                    <SelectItem value="toll">Toll</SelectItem>
                    <SelectItem value="parking">Parking</SelectItem>
                    <SelectItem value="food">Food</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="amount">Amount (₹) *</Label>
                <Input
                  type="number"
                  min="0"
                  step="0.01"
                  placeholder="500"
                  {...register('amount', { valueAsNumber: true })}
                />
                {errors.amount && <p className="text-sm text-red-500 mt-1">{errors.amount.message}</p>}
              </div>

              <div>
                <Label htmlFor="date">Date *</Label>
                <Input
                  type="date"
                  {...register('date')}
                />
                {errors.date && <p className="text-sm text-red-500 mt-1">{errors.date.message}</p>}
              </div>

              <div>
                <Label htmlFor="clientId">Client (Optional)</Label>
                <Select onValueChange={(value) => setValue('clientId', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select client" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients?.map((client: any) => (
                      <SelectItem key={client.id} value={client.id.toString()}>
                        {client.companyName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  placeholder="Brief description..."
                  className="h-20"
                  {...register('description')}
                />
                {errors.description && <p className="text-sm text-red-500 mt-1">{errors.description.message}</p>}
              </div>

              <div>
                <Label>Receipt Upload</Label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                  <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-600 mb-2">
                    {selectedFile ? selectedFile.name : "Click to upload receipt"}
                  </p>
                  <input
                    type="file"
                    accept="image/*,.pdf"
                    onChange={handleFileChange}
                    className="hidden"
                    id="file-upload"
                  />
                  <label htmlFor="file-upload">
                    <Button type="button" variant="outline" size="sm" asChild>
                      <span>Choose File</span>
                    </Button>
                  </label>
                </div>
              </div>

              <Button 
                type="submit" 
                className="w-full"
                disabled={createExpenseMutation.isPending}
              >
                {createExpenseMutation.isPending ? "Adding..." : "Add Expense"}
              </Button>
            </form>
          </div>

          {/* Expense List */}
          <div className="lg:col-span-2">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-gray-900">Recent Expenses</h3>
              <div className="flex space-x-2">
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="fuel">Fuel</SelectItem>
                    <SelectItem value="toll">Toll</SelectItem>
                    <SelectItem value="parking">Parking</SelectItem>
                    <SelectItem value="food">Food</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
                <Input
                  type="date"
                  value={filterDate}
                  onChange={(e) => setFilterDate(e.target.value)}
                  className="w-40"
                />
              </div>
            </div>

            {isLoading ? (
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <Card key={i}>
                    <CardContent className="p-4">
                      <div className="animate-pulse">
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-gray-200 rounded-lg"></div>
                          <div className="space-y-2 flex-1">
                            <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                            <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                          </div>
                          <div className="h-6 bg-gray-200 rounded w-16"></div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : filteredExpenses.length === 0 ? (
              <div className="text-center py-12">
                <Receipt className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No expenses found</h3>
                <p className="text-gray-500">Start tracking your travel expenses</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredExpenses.map((expense: Expense) => (
                  <Card key={expense.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className={`w-10 h-10 ${getExpenseIconBg(expense.type)} rounded-lg flex items-center justify-center`}>
                            {getExpenseIcon(expense.type)}
                          </div>
                          <div className="ml-3">
                            <p className="font-medium text-gray-900 capitalize">{expense.type}</p>
                            <p className="text-sm text-gray-600">{expense.description || 'No description'}</p>
                            <p className="text-xs text-gray-500">
                              {format(new Date(expense.date), 'MMM dd, yyyy')} • {getClientName(expense.clientId)}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-gray-900">₹{parseFloat(expense.amount.toString()).toLocaleString('en-IN')}</p>
                          <div className="mt-1 space-x-2">
                            {expense.receiptUrl && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => window.open(expense.receiptUrl!, '_blank')}
                              >
                                <Eye className="w-4 h-4" />
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDelete(expense)}
                              disabled={deleteExpenseMutation.isPending}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
