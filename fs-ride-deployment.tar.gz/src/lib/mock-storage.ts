// Mock storage for GitHub Pages deployment (frontend-only)
import type { Client, Invoice, Expense, Trip } from '@/../../shared/schema';

export class MockStorage {
  private clients: Client[] = [
    {
      id: 1,
      companyName: "ABC Transport Ltd",
      contactPerson: "John Smith",
      email: "john@abctransport.com",
      phone: "+91-9876543210",
      gstin: "27AABCU9603R1ZM",
      address: "123 Business Park",
      city: "Mumbai",
      state: "Maharashtra",
      pincode: "400001",
      createdAt: new Date('2024-01-15')
    },
    {
      id: 2,
      companyName: "XYZ Logistics",
      contactPerson: "Sarah Wilson",
      email: "sarah@xyzlogistics.com",
      phone: "+91-9876543211",
      gstin: "29AABCU9603R1ZX",
      address: "456 Industrial Area",
      city: "Pune",
      state: "Maharashtra",
      pincode: "411001",
      createdAt: new Date('2024-01-20')
    }
  ];

  private invoices: Invoice[] = [
    {
      id: 1,
      invoiceNumber: "INV-2024-001",
      clientId: 1,
      invoiceDate: new Date('2024-02-01'),
      subtotal: "15000.00",
      cgst: "9.0",
      sgst: "9.0",
      igst: null,
      gstAmount: "2700.00",
      totalAmount: "17700.00",
      status: "Paid",
      items: [
        {
          description: "Mumbai to Pune Travel",
          quantity: 2,
          rate: 12,
          amount: 3600,
          distance: 150,
          distanceRate: 12
        }
      ],
      createdAt: new Date('2024-02-01')
    }
  ];

  private expenses: Expense[] = [
    {
      id: 1,
      date: new Date('2024-02-01'),
      clientId: 1,
      type: "Fuel",
      description: "Petrol for Mumbai-Pune trip",
      amount: "2500.00",
      receiptUrl: null,
      tripId: 1,
      createdAt: new Date('2024-02-01')
    }
  ];

  private trips: Trip[] = [
    {
      id: 1,
      clientId: 1,
      distance: "150.5",
      duration: "3h 15m",
      startLocation: "Mumbai",
      endLocation: "Pune",
      tripDate: new Date('2024-02-01'),
      routeType: "Highway",
      createdAt: new Date('2024-02-01')
    }
  ];

  // Mock API methods
  async getClients(): Promise<Client[]> {
    return Promise.resolve([...this.clients]);
  }

  async getInvoices(): Promise<Invoice[]> {
    return Promise.resolve([...this.invoices]);
  }

  async getExpenses(): Promise<Expense[]> {
    return Promise.resolve([...this.expenses]);
  }

  async getTrips(): Promise<Trip[]> {
    return Promise.resolve([...this.trips]);
  }

  async getDashboardStats(): Promise<{
    totalInvoices: number;
    totalRevenue: string;
    activeClients: number;
    totalDistance: string;
  }> {
    const totalInvoices = this.invoices.length;
    const totalRevenue = this.invoices.reduce((sum, inv) => sum + parseFloat(inv.totalAmount), 0);
    const activeClients = new Set(this.invoices.map(inv => inv.clientId)).size;
    const totalDistance = this.trips.reduce((sum, trip) => sum + parseFloat(trip.distance), 0);

    return Promise.resolve({
      totalInvoices,
      totalRevenue: `₹${totalRevenue.toLocaleString()}`,
      activeClients,
      totalDistance: `${totalDistance.toFixed(1)}km`
    });
  }

  async createClient(client: Omit<Client, 'id' | 'createdAt'>): Promise<Client> {
    const newClient: Client = {
      ...client,
      id: Math.max(...this.clients.map(c => c.id), 0) + 1,
      createdAt: new Date()
    };
    this.clients.push(newClient);
    return Promise.resolve(newClient);
  }

  async createInvoice(invoice: Omit<Invoice, 'id' | 'invoiceNumber' | 'createdAt'>): Promise<Invoice> {
    const newInvoice: Invoice = {
      ...invoice,
      id: Math.max(...this.invoices.map(i => i.id), 0) + 1,
      invoiceNumber: `INV-2024-${(this.invoices.length + 1).toString().padStart(3, '0')}`,
      createdAt: new Date()
    };
    this.invoices.push(newInvoice);
    return Promise.resolve(newInvoice);
  }

  async createExpense(expense: Omit<Expense, 'id' | 'createdAt'>): Promise<Expense> {
    const newExpense: Expense = {
      ...expense,
      id: Math.max(...this.expenses.map(e => e.id), 0) + 1,
      createdAt: new Date()
    };
    this.expenses.push(newExpense);
    return Promise.resolve(newExpense);
  }

  async createTrip(trip: Omit<Trip, 'id' | 'createdAt'>): Promise<Trip> {
    const newTrip: Trip = {
      ...trip,
      id: Math.max(...this.trips.map(t => t.id), 0) + 1,
      createdAt: new Date()
    };
    this.trips.push(newTrip);
    return Promise.resolve(newTrip);
  }
}

export const mockStorage = new MockStorage();