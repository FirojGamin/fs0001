import { Card, CardContent } from "@/components/ui/card";
import { FileText, IndianRupee, Users, Route } from "lucide-react";
import { motion } from "framer-motion";
import { useDashboardData } from "@/hooks/use-dashboard-data";
import { Skeleton } from "@/components/ui/skeleton";

export default function StatsCards() {
  const { data: stats, isLoading } = useDashboardData();

  const cards = [
    {
      title: "Total Invoices",
      value: stats?.totalInvoices ?? 0,
      icon: FileText,
      bgColor: "bg-blue-50",
      iconColor: "text-blue-500",
    },
    {
      title: "Total Revenue",
      value: stats?.totalRevenue ?? "₹0",
      icon: IndianRupee,
      bgColor: "bg-green-50",
      iconColor: "text-green-500",
    },
    {
      title: "Active Clients",
      value: stats?.activeClients ?? 0,
      icon: Users,
      bgColor: "bg-yellow-50",
      iconColor: "text-yellow-500",
    },
    {
      title: "Total Distance",
      value: stats?.totalDistance ?? "0 km",
      icon: Route,
      bgColor: "bg-blue-50",
      iconColor: "text-blue-500",
    },
  ];

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Skeleton className="h-12 w-12 rounded-lg" />
                <div className="ml-4 space-y-2">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-6 w-16" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {cards.map((card, index) => (
        <motion.div
          key={card.title}
          initial={{ opacity: 0, y: 20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ 
            duration: 0.5, 
            delay: index * 0.1,
            type: "spring",
            stiffness: 100
          }}
          whileHover={{ 
            scale: 1.02
          }}
          style={{
            boxShadow: "0 4px 6px rgba(0,0,0,0.05)"
          }}
          whileTap={{ scale: 0.98 }}
        >
          <Card className="border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-300">
            <CardContent className="p-6">
              <div className="flex items-center">
                <motion.div 
                  className={`p-3 rounded-lg ${card.bgColor}`}
                  whileHover={{ rotate: 5 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <card.icon className={`w-6 h-6 ${card.iconColor}`} />
                </motion.div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">{card.title}</p>
                  <motion.p 
                    className="text-2xl font-semibold text-gray-900"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ 
                      delay: index * 0.1 + 0.3,
                      type: "spring",
                      stiffness: 200 
                    }}
                  >
                    {card.value}
                  </motion.p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}
