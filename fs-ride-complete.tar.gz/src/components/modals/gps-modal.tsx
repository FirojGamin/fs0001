import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Route, MapPin, Save, Clock } from "lucide-react";
import { insertTripSchema } from "@shared/schema";
import { z } from "zod";
import { format } from "date-fns";

const gpsFormSchema = z.object({
  startLocation: z.string().min(1, "Start location is required"),
  endLocation: z.string().min(1, "End location is required"),
  tripDate: z.string().min(1, "Trip date is required"),
  clientId: z.string().optional(),
});

type GpsFormData = z.infer<typeof gpsFormSchema>;

interface GpsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface RouteResult {
  distance: number;
  duration: string;
  routeType: string;
}

export default function GpsModal({ isOpen, onClose }: GpsModalProps) {
  const [routeResult, setRouteResult] = useState<RouteResult | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: clients } = useQuery({
    queryKey: ["/api/clients"],
  });

  const { data: trips } = useQuery({
    queryKey: ["/api/trips"],
  });

  const { register, handleSubmit, formState: { errors }, reset, watch, setValue } = useForm<GpsFormData>({
    resolver: zodResolver(gpsFormSchema),
    defaultValues: {
      tripDate: new Date().toISOString().split('T')[0],
    },
  });

  const calculateDistanceMutation = useMutation({
    mutationFn: (data: { startLocation: string; endLocation: string }) => 
      apiRequest("POST", "/api/gps/calculate", data),
    onSuccess: (response: any) => {
      setRouteResult(response);
      toast({
        title: "Success",
        description: "Distance calculated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to calculate distance",
        variant: "destructive",
      });
    },
  });

  const saveTripMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/trips", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/trips"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Trip saved successfully",
      });
      setRouteResult(null);
      reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save trip",
        variant: "destructive",
      });
    },
  });

  const watchedValues = watch();

  const handleCalculateDistance = () => {
    if (!watchedValues.startLocation || !watchedValues.endLocation) {
      toast({
        title: "Error",
        description: "Please enter both start and end locations",
        variant: "destructive",
      });
      return;
    }

    setIsCalculating(true);
    calculateDistanceMutation.mutate({
      startLocation: watchedValues.startLocation,
      endLocation: watchedValues.endLocation,
    });
    setIsCalculating(false);
  };

  const handleSaveTrip = () => {
    if (!routeResult) return;

    const tripData = {
      startLocation: watchedValues.startLocation,
      endLocation: watchedValues.endLocation,
      distance: routeResult.distance.toString(),
      duration: routeResult.duration,
      routeType: routeResult.routeType,
      tripDate: watchedValues.tripDate,
      clientId: watchedValues.clientId ? parseInt(watchedValues.clientId) : null,
    };

    saveTripMutation.mutate(tripData);
  };

  const recentTrips = trips?.slice(-5) || [];

  const getClientName = (clientId: number | null) => {
    if (!clientId) return "No client";
    const client = clients?.find((c: any) => c.id === clientId);
    return client?.companyName || "Unknown Client";
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>GPS Distance Calculator</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Route Input Form */}
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-4">Calculate Route Distance</h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="startLocation">Start Location *</Label>
                <Input
                  placeholder="Enter starting point..."
                  {...register('startLocation')}
                />
                {errors.startLocation && <p className="text-sm text-red-500 mt-1">{errors.startLocation.message}</p>}
              </div>

              <div>
                <Label htmlFor="endLocation">End Location *</Label>
                <Input
                  placeholder="Enter destination..."
                  {...register('endLocation')}
                />
                {errors.endLocation && <p className="text-sm text-red-500 mt-1">{errors.endLocation.message}</p>}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="tripDate">Trip Date *</Label>
                  <Input
                    type="date"
                    {...register('tripDate')}
                  />
                  {errors.tripDate && <p className="text-sm text-red-500 mt-1">{errors.tripDate.message}</p>}
                </div>
                <div>
                  <Label htmlFor="clientId">Client</Label>
                  <Select onValueChange={(value) => setValue('clientId', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select client" />
                    </SelectTrigger>
                    <SelectContent>
                      {clients?.map((client: any) => (
                        <SelectItem key={client.id} value={client.id.toString()}>
                          {client.companyName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button 
                type="button" 
                onClick={handleCalculateDistance}
                className="w-full"
                disabled={isCalculating || calculateDistanceMutation.isPending}
              >
                <Route className="w-4 h-4 mr-2" />
                {isCalculating || calculateDistanceMutation.isPending ? "Calculating..." : "Calculate Distance"}
              </Button>
            </div>

            {/* Distance Results */}
            {routeResult && (
              <Card className="mt-6">
                <CardContent className="p-4">
                  <h4 className="font-medium text-gray-900 mb-3">Route Information</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Distance:</span>
                      <span className="font-medium">{routeResult.distance.toFixed(1)} km</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Estimated Time:</span>
                      <span className="font-medium">{routeResult.duration}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Route Type:</span>
                      <span className="font-medium">{routeResult.routeType}</span>
                    </div>
                  </div>

                  <Button 
                    onClick={handleSaveTrip}
                    className="w-full mt-4"
                    disabled={saveTripMutation.isPending}
                  >
                    <Save className="w-4 h-4 mr-2" />
                    {saveTripMutation.isPending ? "Saving..." : "Save Trip Record"}
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Map Display and Recent Trips */}
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-4">Route Preview</h3>
            <div className="h-96 bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center mb-6">
              <div className="text-center">
                <MapPin className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 font-medium">Google Maps Integration</p>
                <p className="text-sm text-gray-500">Route will be displayed here</p>
                <p className="text-xs text-gray-400 mt-2">
                  {routeResult ? 
                    `${watchedValues.startLocation} → ${watchedValues.endLocation}` : 
                    "Enter locations and calculate distance"
                  }
                </p>
              </div>
            </div>

            {/* Recent Trips */}
            <div>
              <h4 className="font-medium text-gray-900 mb-3">Recent Trips</h4>
              {recentTrips.length === 0 ? (
                <div className="text-center py-8">
                  <Route className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">No trips recorded yet</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {recentTrips.map((trip: any) => (
                    <Card key={trip.id}>
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium text-gray-900">
                              {trip.startLocation} → {trip.endLocation}
                            </p>
                            <p className="text-sm text-gray-500 flex items-center">
                              <Clock className="w-3 h-3 mr-1" />
                              {format(new Date(trip.tripDate), 'MMM dd, yyyy')}
                              {trip.clientId && ` • ${getClientName(trip.clientId)}`}
                            </p>
                          </div>
                          <span className="font-medium text-gray-900">
                            {parseFloat(trip.distance).toFixed(0)} km
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
