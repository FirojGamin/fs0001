import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2, Eye, Download } from "lucide-react";
import { insertInvoiceSchema, type InvoiceItem } from "@shared/schema";
import { z } from "zod";
import { generateInvoicePDF } from "@/lib/pdf-generator";

const invoiceFormSchema = insertInvoiceSchema.extend({
  clientId: z.string().min(1, "Client is required"),
  invoiceDate: z.string().min(1, "Invoice date is required"),
  items: z.array(z.object({
    description: z.string().min(1, "Description is required"),
    quantity: z.number().min(1, "Quantity must be at least 1"),
    rate: z.number().min(0, "Rate must be non-negative"),
    amount: z.number().min(0, "Amount must be non-negative"),
    distance: z.number().optional(),
    distanceRate: z.number().optional(),
  })).min(1, "At least one item is required"),
});

type InvoiceFormData = z.infer<typeof invoiceFormSchema>;

interface InvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function InvoiceModal({ isOpen, onClose }: InvoiceModalProps) {
  const [items, setItems] = useState<InvoiceItem[]>([
    { description: "", quantity: 1, rate: 0, amount: 0 }
  ]);
  const [previewMode, setPreviewMode] = useState(false);
  const [itemType, setItemType] = useState<'standard' | 'distance'>('standard');
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: clients } = useQuery({
    queryKey: ["/api/clients"],
  });

  const { register, handleSubmit, watch, setValue, formState: { errors }, reset } = useForm<InvoiceFormData>({
    resolver: zodResolver(invoiceFormSchema),
    defaultValues: {
      invoiceDate: new Date().toISOString().split('T')[0],
      cgst: "9",
      sgst: "9",
      igst: "0",
      status: "draft",
    },
  });

  const createInvoiceMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/invoices", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Invoice created successfully",
      });
      onClose();
      reset();
      setItems([{ description: "", quantity: 1, rate: 0, amount: 0 }]);
      setPreviewMode(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create invoice",
        variant: "destructive",
      });
    },
  });

  const watchedValues = watch();
  const cgst = parseFloat(watchedValues.cgst?.toString() || "0");
  const sgst = parseFloat(watchedValues.sgst?.toString() || "0");
  const igst = parseFloat(watchedValues.igst?.toString() || "0");

  const addItem = () => {
    if (itemType === 'distance') {
      setItems([...items, { description: "", quantity: 1, rate: 0, amount: 0, distance: 0, distanceRate: 0 }]);
    } else {
      setItems([...items, { description: "", quantity: 1, rate: 0, amount: 0 }]);
    }
  };

  const removeItem = (index: number) => {
    if (items.length > 1) {
      const newItems = items.filter((_, i) => i !== index);
      setItems(newItems);
      setValue('items', newItems);
    }
  };

  const updateItem = (index: number, field: keyof InvoiceItem, value: string | number) => {
    const newItems = [...items];
    newItems[index] = { 
      ...newItems[index], 
      [field]: field === 'description' ? value : Number(value) 
    };
    
    // Calculate amount based on item type
    if (field === 'quantity' || field === 'rate' || field === 'distance' || field === 'distanceRate') {
      const item = newItems[index];
      if (item.distance && item.distanceRate) {
        // Distance-based calculation: distance * rate per km * quantity
        item.amount = item.distance * item.distanceRate * item.quantity;
      } else {
        // Standard calculation: quantity * rate
        item.amount = item.quantity * item.rate;
      }
    }
    
    setItems(newItems);
    setValue('items', newItems);
  };

  const subtotal = items.reduce((sum, item) => sum + item.amount, 0);
  const gstAmount = subtotal * ((cgst + sgst + igst) / 100);
  const totalAmount = subtotal + gstAmount;

  const onSubmit = (data: InvoiceFormData) => {
    const invoiceData = {
      ...data,
      clientId: parseInt(data.clientId),
      invoiceDate: new Date(data.invoiceDate),
      subtotal: subtotal.toString(),
      cgst: cgst.toString(),
      sgst: sgst.toString(),
      igst: igst.toString(),
      gstAmount: gstAmount.toString(),
      totalAmount: totalAmount.toString(),
      items: items,
    };
    
    createInvoiceMutation.mutate(invoiceData);
  };

  const handlePreview = () => {
    const client = clients?.find((c: any) => c.id === parseInt(watchedValues.clientId || "0"));
    if (!client) {
      toast({
        title: "Error",
        description: "Please select a client first",
        variant: "destructive",
      });
      return;
    }
    setPreviewMode(true);
  };

  const handleDownloadPDF = () => {
    const client = clients?.find((c: any) => c.id === parseInt(watchedValues.clientId || "0"));
    if (!client) return;

    const invoiceData = {
      invoiceNumber: `INV-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 1000)).padStart(3, '0')}`,
      client,
      items,
      subtotal,
      cgst,
      sgst,
      igst,
      gstAmount,
      totalAmount,
      invoiceDate: watchedValues.invoiceDate,
    };

    generateInvoicePDF(invoiceData);
  };

  const selectedClient = clients?.find((c: any) => c.id === parseInt(watchedValues.clientId || "0"));

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{previewMode ? "Invoice Preview" : "Create New Invoice"}</DialogTitle>
        </DialogHeader>

        {previewMode ? (
          <div className="space-y-6">
            {/* Invoice Preview */}
            <div className="bg-white p-8 border rounded-lg">
              <div className="flex justify-between items-start mb-8">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900">FS RIDE</h1>
                  <p className="text-gray-600">Travel Billing Services</p>
                </div>
                <div className="text-right">
                  <h2 className="text-2xl font-bold text-gray-900">INVOICE</h2>
                  <p className="text-gray-600">#{`INV-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 1000)).padStart(3, '0')}`}</p>
                  <p className="text-gray-600">Date: {new Date(watchedValues.invoiceDate || Date.now()).toLocaleDateString()}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-8 mb-8">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Bill To:</h3>
                  <div className="text-gray-600">
                    <p className="font-semibold">{selectedClient?.companyName}</p>
                    <p>{selectedClient?.contactPerson}</p>
                    <p>{selectedClient?.email}</p>
                    <p>{selectedClient?.phone}</p>
                    {selectedClient?.gstin && <p>GSTIN: {selectedClient.gstin}</p>}
                  </div>
                </div>
              </div>

              <div className="mb-8">
                <table className="w-full border-collapse border border-gray-300">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="border border-gray-300 px-4 py-2 text-left">Description</th>
                      <th className="border border-gray-300 px-4 py-2 text-center">Details</th>
                      <th className="border border-gray-300 px-4 py-2 text-right">Rate</th>
                      <th className="border border-gray-300 px-4 py-2 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((item, index) => (
                      <tr key={index}>
                        <td className="border border-gray-300 px-4 py-2">{item.description}</td>
                        <td className="border border-gray-300 px-4 py-2 text-center">
                          {item.distance && item.distanceRate ? (
                            <div className="text-sm">
                              <div>{item.distance}km × {item.quantity} trips</div>
                              <div className="text-gray-600">@₹{item.distanceRate}/km</div>
                            </div>
                          ) : (
                            <div>{item.quantity} × ₹{item.rate.toFixed(2)}</div>
                          )}
                        </td>
                        <td className="border border-gray-300 px-4 py-2 text-right">
                          {item.distance && item.distanceRate ? (
                            `₹${item.distanceRate}/km`
                          ) : (
                            `₹${item.rate.toFixed(2)}`
                          )}
                        </td>
                        <td className="border border-gray-300 px-4 py-2 text-right">₹{item.amount.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex justify-end">
                <div className="w-64">
                  <div className="flex justify-between py-2">
                    <span>Subtotal:</span>
                    <span>₹{subtotal.toFixed(2)}</span>
                  </div>
                  {cgst > 0 && (
                    <div className="flex justify-between py-2">
                      <span>CGST ({cgst}%):</span>
                      <span>₹{(subtotal * cgst / 100).toFixed(2)}</span>
                    </div>
                  )}
                  {sgst > 0 && (
                    <div className="flex justify-between py-2">
                      <span>SGST ({sgst}%):</span>
                      <span>₹{(subtotal * sgst / 100).toFixed(2)}</span>
                    </div>
                  )}
                  {igst > 0 && (
                    <div className="flex justify-between py-2">
                      <span>IGST ({igst}%):</span>
                      <span>₹{(subtotal * igst / 100).toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between py-2 border-t font-bold text-lg">
                    <span>Total:</span>
                    <span>₹{totalAmount.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-4">
              <Button variant="outline" onClick={() => setPreviewMode(false)}>
                Back to Edit
              </Button>
              <Button onClick={handleDownloadPDF}>
                <Download className="w-4 h-4 mr-2" />
                Download PDF
              </Button>
              <Button onClick={handleSubmit(onSubmit)} disabled={createInvoiceMutation.isPending}>
                {createInvoiceMutation.isPending ? "Creating..." : "Create Invoice"}
              </Button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            {/* Client and Date Selection */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="clientId">Client *</Label>
                <Select onValueChange={(value) => setValue('clientId', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select Client" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients?.map((client: any) => (
                      <SelectItem key={client.id} value={client.id.toString()}>
                        {client.companyName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.clientId && <p className="text-sm text-red-500 mt-1">{errors.clientId.message}</p>}
              </div>

              <div>
                <Label htmlFor="invoiceDate">Invoice Date *</Label>
                <Input
                  type="date"
                  {...register('invoiceDate')}
                />
                {errors.invoiceDate && <p className="text-sm text-red-500 mt-1">{errors.invoiceDate.message}</p>}
              </div>
            </div>

            {/* Invoice Items */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-gray-900">Invoice Items</h3>
                <div className="flex items-center space-x-4">
                  <Select value={itemType} onValueChange={(value: 'standard' | 'distance') => setItemType(value)}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="standard">Standard Items</SelectItem>
                      <SelectItem value="distance">Distance-Based</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button type="button" onClick={addItem} variant="outline">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Item
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                {items.map((item, index) => (
                  <Card key={index}>
                    <CardContent className="p-4">
                      {itemType === 'distance' ? (
                        // Distance-based item form
                        <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
                          <div className="md:col-span-2">
                            <Label>Travel Route *</Label>
                            <Input
                              placeholder="Mumbai to Pune"
                              value={item.description}
                              onChange={(e) => updateItem(index, 'description', e.target.value)}
                            />
                          </div>
                          <div>
                            <Label>Distance (km) *</Label>
                            <Input
                              type="number"
                              min="0"
                              step="0.1"
                              value={item.distance || 0}
                              onChange={(e) => updateItem(index, 'distance', e.target.value)}
                            />
                          </div>
                          <div>
                            <Label>Rate/km (₹) *</Label>
                            <Input
                              type="number"
                              min="0"
                              step="0.01"
                              value={item.distanceRate || 0}
                              onChange={(e) => updateItem(index, 'distanceRate', e.target.value)}
                            />
                          </div>
                          <div>
                            <Label>Trips</Label>
                            <Input
                              type="number"
                              min="1"
                              value={item.quantity}
                              onChange={(e) => updateItem(index, 'quantity', e.target.value)}
                            />
                          </div>
                          <div className="flex items-end">
                            <Button
                              type="button"
                              variant="destructive"
                              size="icon"
                              onClick={() => removeItem(index)}
                              disabled={items.length === 1}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ) : (
                        // Standard item form
                        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                          <div className="md:col-span-2">
                            <Label>Description *</Label>
                            <Input
                              placeholder="Service description"
                              value={item.description}
                              onChange={(e) => updateItem(index, 'description', e.target.value)}
                            />
                          </div>
                          <div>
                            <Label>Quantity *</Label>
                            <Input
                              type="number"
                              min="1"
                              value={item.quantity}
                              onChange={(e) => updateItem(index, 'quantity', e.target.value)}
                            />
                          </div>
                          <div>
                            <Label>Rate (₹) *</Label>
                            <Input
                              type="number"
                              min="0"
                              step="0.01"
                              value={item.rate}
                              onChange={(e) => updateItem(index, 'rate', e.target.value)}
                            />
                          </div>
                          <div className="flex items-end">
                            <Button
                              type="button"
                              variant="destructive"
                              size="icon"
                              onClick={() => removeItem(index)}
                              disabled={items.length === 1}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      )}
                      <div className="mt-2 text-right">
                        <span className="text-sm text-gray-600">Amount: ₹{item.amount.toFixed(2)}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* GST Configuration */}
            <Card>
              <CardContent className="p-4">
                <h3 className="text-lg font-medium text-gray-900 mb-4">GST Configuration</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <Label htmlFor="cgst">CGST (%)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      max="100"
                      {...register('cgst')}
                    />
                  </div>
                  <div>
                    <Label htmlFor="sgst">SGST (%)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      max="100"
                      {...register('sgst')}
                    />
                  </div>
                  <div>
                    <Label htmlFor="igst">IGST (%)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      max="100"
                      {...register('igst')}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Invoice Summary */}
            <Card>
              <CardContent className="p-4">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Invoice Summary</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Subtotal:</span>
                    <span className="font-medium">₹{subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">GST:</span>
                    <span className="font-medium">₹{gstAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-lg font-semibold border-t pt-2">
                    <span>Total Amount:</span>
                    <span>₹{totalAmount.toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="flex justify-end space-x-4 pt-6 border-t">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="button" variant="outline" onClick={handlePreview}>
                <Eye className="w-4 h-4 mr-2" />
                Preview
              </Button>
              <Button type="submit" disabled={createInvoiceMutation.isPending}>
                {createInvoiceMutation.isPending ? "Creating..." : "Create Invoice"}
              </Button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
