import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import StatsCards from "@/components/dashboard/stats-cards";
import RecentActivity from "@/components/dashboard/recent-activity";
import InvoiceModal from "@/components/modals/invoice-modal";
import ClientModal from "@/components/modals/client-modal";
import ExpenseModal from "@/components/modals/expense-modal";
import GpsModal from "@/components/modals/gps-modal";
import { useIsMobile } from "@/hooks/use-mobile";

export default function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const isMobile = useIsMobile();

  const openModal = (modalName: string) => {
    setActiveModal(modalName);
    if (isMobile) {
      document.body.style.overflow = 'hidden';
    }
  };

  const closeModal = () => {
    setActiveModal(null);
    document.body.style.overflow = 'auto';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="lg:hidden"
          >
            <Sidebar 
              isOpen={sidebarOpen} 
              onClose={() => setSidebarOpen(false)}
              onNavigate={openModal}
            />
          </motion.div>
        )}
      </AnimatePresence>
      
      <Sidebar 
        isOpen={sidebarOpen} 
        onClose={() => setSidebarOpen(false)}
        onNavigate={openModal}
      />
      
      <motion.div 
        className="lg:pl-64"
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Header 
          onMenuClick={() => setSidebarOpen(true)}
          onNewInvoice={() => openModal('invoice')}
        />
        
        <motion.main 
          className="p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
        >
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
          >
            <StatsCards />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
          >
            <RecentActivity />
          </motion.div>
        </motion.main>
      </motion.div>

      {/* Modals */}
      <InvoiceModal 
        isOpen={activeModal === 'invoice'} 
        onClose={closeModal} 
      />
      <ClientModal 
        isOpen={activeModal === 'clients'} 
        onClose={closeModal} 
      />
      <ExpenseModal 
        isOpen={activeModal === 'expenses'} 
        onClose={closeModal} 
      />
      <GpsModal 
        isOpen={activeModal === 'gps'} 
        onClose={closeModal} 
      />
    </div>
  );
}
